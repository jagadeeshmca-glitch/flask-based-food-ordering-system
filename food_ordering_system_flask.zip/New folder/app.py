# app.py - FINAL COMPLETE CODE

from functools import wraps
import os 
from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    UserMixin,
    login_user,
    LoginManager,
    login_required,
    logout_user,
    current_user,
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename 
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, DecimalField
from wtforms.fields.simple import FileField 
from wtforms.validators import DataRequired, Email, EqualTo, NumberRange, ValidationError
from sqlalchemy import func 
from sqlalchemy.orm import joinedload 

# --- Application and Database Setup ---
app = Flask(__name__)
app.config["SECRET_KEY"] = "your_secret_key_for_security_42"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///food_ordering.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Configuration for Image Uploads
UPLOAD_FOLDER = 'static/dish_images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

db = SQLAlchemy(app)

# --- Flask-Login Setup ---
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):
    """Loads the user object from the database using the user ID."""
    if user_id is None:
        return None
    try:
        return User.query.get(int(user_id))
    except (ValueError, TypeError):
        return None


# --- Database Models ---
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    orders = db.relationship("Order", backref="customer", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Dish(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255))
    price = db.Column(db.Float, nullable=False)
    image_filename = db.Column(db.String(100), nullable=True) 


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default="Pending")
    items = db.relationship("OrderItem", backref="order", lazy=True)


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    dish_id = db.Column(db.Integer, db.ForeignKey("dish.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    dish = db.relationship("Dish")


# --- Forms ---
class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class RegisterForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    password2 = PasswordField(
        "Repeat Password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match")],
    )
    submit = SubmitField("Register")

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError("Username already exists.")

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError("Email address already registered.")


class DishForm(FlaskForm):
    name = StringField("Dish Name", validators=[DataRequired()])
    description = StringField("Description")
    price = DecimalField(
        "Price",
        validators=[DataRequired(), NumberRange(min=0.01, message="Price must be greater than 0")],
    )
    # FileField requires the enctype="multipart/form-data" attribute on the HTML form
    image = FileField('Dish Image (Optional)') 
    submit = SubmitField("Add Dish")


# --- Helper: Admin-only decorator ---
def admin_required(f):
    """Decorator to restrict access to authenticated admin users only."""
    @wraps(f)
    @login_required 
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash("Admin access required.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated_function


# --- User Authentication Routes ---
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash("Invalid username or password", "danger")
            return redirect(url_for("login"))

        login_user(user)
        next_page = request.args.get("next")

        if user.is_admin:
            return redirect(url_for("admin_dashboard"))

        return redirect(next_page or url_for("index"))
    return render_template("login.html", form=form)


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# --- User Modules ---
CART = {}


@app.route("/")
def index():
    dishes = Dish.query.all()
    cart_key = current_user.id if current_user.is_authenticated else "guest_session"
    current_cart = CART.get(cart_key, {})
    cart_item_count = sum(current_cart.values())

    return render_template("index.html", dishes=dishes, cart_count=cart_item_count)


@app.route("/add_to_cart/<int:dish_id>")
@login_required
def add_to_cart(dish_id):
    dish = Dish.query.get_or_404(dish_id)
    cart_key = current_user.id

    if cart_key not in CART:
        CART[cart_key] = {}

    CART[cart_key][dish_id] = CART[cart_key].get(dish_id, 0) + 1

    flash(f'1x {dish.name} added to cart!', "success")
    return redirect(url_for("index"))


@app.route("/cart")
@login_required
def view_cart():
    cart_key = current_user.id
    cart_items = CART.get(cart_key, {})

    items_to_display = []
    total_price = 0.0

    for dish_id, quantity in cart_items.items():
        dish = Dish.query.get(dish_id)
        if dish:
            item_total = dish.price * quantity
            items_to_display.append({"dish": dish, "quantity": quantity, "total": item_total})
            total_price += item_total

    cart_item_count = sum(cart_items.values())
    return render_template("cart.html", items=items_to_display, total_price=total_price, cart_count=cart_item_count)


@app.route("/place_order")
@login_required
def place_order():
    cart_key = current_user.id
    cart_items = CART.get(cart_key, {})

    if not cart_items:
        flash("Your cart is empty. Nothing to order.", "warning")
        return redirect(url_for("index"))

    calculated_total = 0.0
    valid_items = []

    for dish_id, quantity in cart_items.items():
        dish = Dish.query.get(dish_id)
        if dish:
            calculated_total += dish.price * quantity
            valid_items.append((dish_id, quantity))

    if not valid_items:
        flash("The items in your cart are no longer available.", "warning")
        CART[cart_key] = {} 
        return redirect(url_for("index"))

    new_order = Order(user_id=current_user.id, total_price=calculated_total)
    db.session.add(new_order)
    db.session.flush()

    for dish_id, quantity in valid_items:
        item = OrderItem(order_id=new_order.id, dish_id=dish_id, quantity=quantity)
        db.session.add(item)

    db.session.commit()
    CART[cart_key] = {}

    flash(f"Order #{new_order.id} placed successfully! Total: ₹{calculated_total:.2f}", "success")
    return redirect(url_for("index"))


# --- Admin Modules ---
@app.route("/admin")
@admin_required
def admin_dashboard():
    form = DishForm()

    # Fetch data for dashboard metrics
    dishes_count = Dish.query.count()
    pending_orders_count = Order.query.filter_by(status="Pending").count()

    # Fetch a preview of dishes
    dishes_preview = Dish.query.order_by(Dish.id.desc()).all() 

    # Calculate Total Revenue (using SQLAlchemy functions for efficiency)
    total_revenue_result = db.session.query(func.sum(Order.total_price)).scalar()
    total_revenue = total_revenue_result if total_revenue_result is not None else 0.0

    return render_template(
        "admin/dashboard.html",
        form=form,
        cart_count=0,
        dishes_count=dishes_count,
        pending_orders_count=pending_orders_count,
        total_revenue=total_revenue,
        dishes_preview=dishes_preview,
    )


@app.route("/admin/add_dish", methods=["GET", "POST"])
@admin_required
def add_dish():
    form = DishForm()

    if form.validate_on_submit():
        image_fn = None
        
        # Handle Image Upload
        if form.image.data:
            filename = secure_filename(form.image.data.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            # Save the file to the file system
            form.image.data.save(file_path)
            
            image_fn = filename
            flash(f"Image '{filename}' uploaded successfully.", "info")

        # Create new dish instance
        new_dish = Dish( 
            name=form.name.data,
            description=form.description.data,
            price=form.price.data,
            image_filename=image_fn # Store the filename (or None) in the database
        )
        
        db.session.add(new_dish)
        db.session.commit()
        flash("Dish added successfully!", "success")
        return redirect(url_for("admin_dashboard"))

    return render_template("admin/add_dish.html", form=form, cart_count=0)


@app.route("/admin/edit_dish/<int:dish_id>", methods=["GET", "POST"])
@admin_required
def edit_dish(dish_id):
    """Allows admin to edit the details of an existing dish."""
    dish = Dish.query.get_or_404(dish_id)
    form = DishForm(obj=dish) 

    if form.validate_on_submit():
        
        # Check if a new image was submitted
        if form.image.data:
            
            # 1. Delete the old image file, if it exists
            if dish.image_filename:
                old_file_path = os.path.join(app.config['UPLOAD_FOLDER'], dish.image_filename)
                
                # Use try-except to handle PermissionError/OSError during file deletion
                if os.path.exists(old_file_path):
                    try:
                        os.remove(old_file_path)
                    except OSError as e:
                        print(f"Error deleting old file {old_file_path}: {e}")
                        flash(f"Warning: Could not delete old image file ({dish.image_filename}). Check file permissions.", "warning")

            # 2. Save the new image
            filename = secure_filename(form.image.data.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            form.image.data.save(file_path)
            dish.image_filename = filename # Update database record

        # Update text fields (name, description, price)
        dish.name = form.name.data
        dish.description = form.description.data
        dish.price = form.price.data
        
        db.session.commit()
        flash(f"Dish '{dish.name}' updated successfully!", "success")
        return redirect(url_for("admin_dashboard"))

    return render_template("admin/edit_dish.html", form=form, dish=dish, cart_count=0)


@app.route("/admin/delete_dish/<int:dish_id>", methods=["POST"])
@admin_required
def delete_dish(dish_id):
    """Allows admin to delete a dish by ID."""
    dish = Dish.query.get_or_404(dish_id)
        
    # 1. Check and delete associated image file
    if dish.image_filename:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], dish.image_filename)
        # Use try-except to handle potential errors during deletion
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError as e:
                print(f"Error deleting dish file {file_path}: {e}")
                flash(f"Warning: Could not delete associated image file ({dish.image_filename}).", "warning")
            
    # 2. Delete the dish and commit
    db.session.delete(dish)
    db.session.commit()
    
    flash(f"Dish '{dish.name}' successfully removed.", "success")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/orders")
@admin_required
def view_orders():
    """Displays a list of all orders, efficiently loading customer details."""
    orders = Order.query.options(
        joinedload(Order.customer) 
    ).order_by(Order.id.desc()).all()
    
    return render_template("admin/view_orders.html", orders=orders, cart_count=0)


@app.route("/admin/order_details/<int:order_id>")
@admin_required
def order_details(order_id):
    """Displays detailed information for a specific order."""
    order = Order.query.options(
        joinedload(Order.items).joinedload(OrderItem.dish)
    ).get_or_404(order_id)
    
    return render_template("admin/order_details.html", order=order, cart_count=0)


@app.route("/admin/complete_order/<int:order_id>", methods=["POST"])
@admin_required
def mark_order_completed(order_id):
    """Allows admin to change an order status to 'Completed'."""
    order = Order.query.get_or_404(order_id)

    if order.status == "Completed":
        flash(f"Order #{order.id} is already completed.", "warning")
    else:
        order.status = "Completed"
        db.session.commit()
        flash(f"Order #{order.id} status updated to Completed.", "success")
        
    return redirect(url_for("order_details", order_id=order.id))


# --- Initializer ---
if __name__ == "__main__":
    with app.app_context():
        # --- Database Reset Logic (for initial setup/schema changes) ---
        db_path = app.config["SQLALCHEMY_DATABASE_URI"].replace("sqlite:///", "")
        
        # NOTE: Comment this IF block out if you want to preserve data between runs!
        if os.path.exists(db_path):
            os.remove(db_path)
            print(f"Removed old database file: {db_path} to apply new schema.")
        
        # ----------------------------------------------------

        db.create_all()
        print("Database schema created/updated.")

        # --- Create Admin User if one doesn't exist ---
        if User.query.filter_by(is_admin=True).first() is None:
            admin = User(username="admin", email="admin@food.com", is_admin=True)
            admin.set_password("adminpass")
            db.session.add(admin)
            db.session.commit()
            print("Default admin created: 'admin' / 'adminpass'")

        # --- Seed Dish Data ---
        if Dish.query.count() == 0:
            dishes_to_add = [
                ("Masala Dosa", "Crispy rice pancake with spiced potato filling.", 6.99, "dosa.jpg"),
                ("Chicken Biryani", "Fragrant basmati rice cooked with chicken and spices.", 12.50, "biryani.jpg"),
                ("Paneer Tikka Masala", "Cubes of cottage cheese in a creamy tomato sauce.", 10.99, "paneer.jpg"),
                ("Vada Pav", "Spicy potato dumpling served in a bread bun.", 3.50, "vada_pav.jpg"),
                ("Idli Sambar", "Soft fluffy rice cakes with a lentil vegetable stew.", 4.99, "idli.jpg"),
            ]
            for name, desc, price, img_fn in dishes_to_add:
                dish = Dish(name=name, description=desc, price=price, image_filename=img_fn)
                db.session.add(dish)
            db.session.commit()
            print(f"Added {len(dishes_to_add)} sample dishes.")

    app.run(debug=True)